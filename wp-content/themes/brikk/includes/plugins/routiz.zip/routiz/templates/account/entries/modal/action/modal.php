<div class="rz-modal rz-modal-account-entry-action" data-id="account-entry-action">
    <a href="#" class="rz-close">
        <i class="fas fa-times"></i>
    </a>
    <div class="rz-modal-heading">
        <h4 class="rz--title"><?php esc_html_e( 'Pay Now', 'routiz' ); ?></h4>
    </div>
    <div class="rz-modal-content">
        <div class="rz-modal-append"></div>
        <?php Rz()->preloader(); ?>
    </div>
</div>
