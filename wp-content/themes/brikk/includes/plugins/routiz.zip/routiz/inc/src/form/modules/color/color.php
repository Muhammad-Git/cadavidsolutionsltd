<?php

namespace Routiz\Inc\Src\Form\Modules\Color;

use \Routiz\Inc\Src\Form\Modules\Module;

class Color extends Module {

    // ..

}
