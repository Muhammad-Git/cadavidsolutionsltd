<div class="rz-tab">
    <span class="rz--name">{{ $name }}</span>
</div>
