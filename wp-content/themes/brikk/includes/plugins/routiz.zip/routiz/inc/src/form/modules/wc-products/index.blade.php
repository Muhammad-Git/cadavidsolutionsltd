@php
    $component->render( array_merge( $props, [
        'type' => $props['choice'],
    ]));
@endphp