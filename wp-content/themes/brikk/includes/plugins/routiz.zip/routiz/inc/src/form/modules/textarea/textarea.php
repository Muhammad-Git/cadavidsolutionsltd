<?php

namespace Routiz\Inc\Src\Form\Modules\Textarea;

use \Routiz\Inc\Src\Form\Modules\Module;

class Textarea extends Module {

    // ..

}
