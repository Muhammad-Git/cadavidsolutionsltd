<?php

namespace Routiz\Inc\Src\Form\Modules\Plain_Text;

use \Routiz\Inc\Src\Form\Modules\Module;

class Plain_Text extends Module {

    // ..

}
